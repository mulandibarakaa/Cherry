while true 
do
echo "Starting Asta-Md..."
node lib/client.js
done
