 <h1 align="center"> Asta Md </h1> 
<p align="center"> Introducing Asta_Md, It is designed to bring a whole new level of excitement to your boring WhatsApp use. </p>

<p align="center">
  <a herf="https://leadier-umbrellas.000webhostapp.com/asta-anime3.jpg"></a>
</p>
    
   
   
<p align="center">
  <a href="https://wa.me/+2348039607375?text=Hi+Bro--+I+Need+Help.+I+messaged+you+from+Asta-Md+Repo" target="_blank">
    <img alt="whatsapp" src="https://img.shields.io/badge/ Whatsapp -25D366?style=for-the-badge&logo=whatsapp&logoColor=white" />
  </a>
  <a aria-label="Asta_Md is free to use" href="https://github.com/Astropeda/Asta-Md/blob/main/LICENCE" target="_blank">
    <img alt="License: GPL-3" src="https://badges.frapsoft.com/os/gpl/gpl.png?v=103)](https://opensource.org/licenses/GPL-3.0/" target="_blank" />
  </a>
  <a aria-label="Asta_Md is free to use" href="https://github.com/Astropeda" target="_blank">
  </a>

</p>
<p align="center"><img src="https://profile-counter.glitch.me/{Astropeda}/count.svg" alt="Astropeda:: Visitor's Count" /></p>

---




<p align="center"> ASTA MD whatsapp bot uses
  <a href="https://github.com/adiwajshing/Baileys">Multi-Device Baileys.</a>
</p>
<p align="center">
  <img title="Whatsapp-Bot-Javascript" src="https://img.shields.io/badge/Javascript-363303?style=for-the-badge&logo=javascript&logoColor=c6c631"></img>
</p>

---

<p align="center">
  <a href="https://github.com/Astropeda/Asta-Md"><b>Asta-Md</b></a> Support Deploy On...
</p>

<p align="center">
  <a href="https://github.com/Astropeda/Asta-Md/blob/main/temp/deploy-on-vps.md"><img src="https://img.shields.io/badge/self hosting-3d1513?style=for-the-badge&logo=serverless&logoColor=FD5750"></a>
  <a href="https://railway.app/template/GZOvIe?referralCode=wVDLrh"><img src="https://img.shields.io/badge/railway-3e164f?style=for-the-badge&logo=railway&logoColor=0B0D0E"></a>
</p>
<p align="center">
  <a href="tps://heroku.com/deploy?template=https://github.com/Astropeda/Asta-Md"><img src="https://img.shields.io/badge/heroku-9d7acc?style=for-the-badge&logo=heroku&logoColor=430098"></a>
  <a href=""><img src="https://img.shields.io/badge/replit-253c99?style=for-the-badge&logo=replit&logoColor=F26207"></a>
  <a href="https://app.koyeb.com/apps/deploy?type=git&repository=github.com/Astropeda/Asta-Md-Md&branch=main&env[SESSION_ID]&env[OWNER_NUMBER]=923184474176&env[MONGODB_URI]&&env[OWNER_NAME]=Suhail&env[KOYEB_API]&env[PREFIX]=.&env[WAPRESENCE]&env[AUTO_READ_STATUS]=false&env[DISABLE_PM]=false&env[PACK_AUTHER]=whatsapp+bot&env[PACK_NAME]=Suhail+MD&env[STYLE]=0&env[MODE]=private&env[READ_MESSAGE]=false&env[THEME]=SUHAIL&env[WARN_COUNT]=3&env[BLOCK_JID]=null&env[TIME_ZONE]=Asia/Karachi&name=suhail-md&env[KOYEB_NAME]=suhail-md&env[SUDO]=null&env[THUMB_IMAGE]=https://leadier-umbrellas.000webhostapp.com/asta-anime3.jpg"><img src="https://img.shields.io/badge/koyeb-033604?style=for-the-badge&logo=koyeb&logoColor=white"></a>
</p>
<p align="center">
  <a href="https://leadier-umbrellas.000webhostapp.com/asta-anime3.jpg"><img src="https://img.shields.io/badge/CodeSpace-green?colorA=%23ff000&colorB=%23017e40&style=for-the-badge&logo=git&logoColor=white"></a>
</p>
<p align="center">Need help? please create an <a href="https://github.com/Astropeda/Asta-Md/issues">issue</a></p>
