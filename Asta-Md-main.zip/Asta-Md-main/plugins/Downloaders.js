const { tlang, ringtone, Module_Exports,fetchJson, sleep, botpic, getBuffer, pinterest, prefix, name } = require('../lib')
const { mediafire } = require("../lib/mediafire.js");
const {GDriveDl} = require('../lib/scraper.js')
const googleTTS = require("google-tts-api");
const fetch = require('node-fetch');
const ytdl = require('ytdl-secktor')
const cheerio = require('cheerio')
const fs  = require('fs-extra');
const axios= require('axios');
var videotime = 60000 // 1000 min
var dlsize = 1000 // 1000mb
    //---------------------------------------------------------------------------
//
Module_Exports({
  kingcmd: "wikimedia",
  infocmd: "Downloads wikimedia images.",
  kingclass: "downloader commands",
  kingpath: __filename,
  use: "<text|search.>"
}, async (_0x47fb55, _0x5614e8) => {
  try {
    if (!_0x5614e8) {
      return await _0x47fb55.send("*_Please Give me search query!_*");
    }
    let {
      wikimedia: _0x168a95
    } = require("../lib");
    let _0x6c377e = (await _0x168a95(_0x5614e8)) || [];
    if (!_0x6c377e || !_0x6c377e[0]) {
      return await _0x47fb55.send("*_No Results Found!_*");
    }
    let _0xc4fe0 = _0x47fb55.iscreator && _0x5614e8.split("|")[1] === "all" ? _0x6c377e.length : _0x6c377e.length > 5 ? 5 : _0x6c377e.length;
    for (let _0xfe1387 = 0; _0xfe1387 < _0xc4fe0; _0xfe1387++) {
      try {
        _0x47fb55.bot.sendFromUrl(_0x47fb55.from, _0x6c377e[_0xfe1387].image, "Title: " + _0x6c377e[_0xfe1387].title + "\n*Source:* " + _0x6c377e[_0xfe1387].source, _0x47fb55, {}, "image");
      } catch {}
    }
  } catch (_0x289d8e) {
    await _0x47fb55.error(_0x289d8e + "\n\ncommand: insta", _0x289d8e);
  }
});
//
Module_Exports({
            kingcmd: "tgs",
            infocmd: "Downloads telegram stickers.",
            kingclass: "downloader commands",
            kingpath: __filename,
            use: '<add sticker url.>'
        },
        async(Void, citel, text) => {
		if (!text) return await citel.reply("Enter a tg sticker url_l\nExample: .tgs https://t.me/addstickers/Oldboyfinal\nKeep in mind that there is a chance of ban if used always.");
		if (!text.includes("addstickers"))  return await citel.reply("_Uhh Please Enter a Valid tg sticker url_\nExample: .tgs https://t.me/addstickers/Oldboyfinal");
		let tgUrl = text.split("|")[0];
		let find = tgUrl.split("/addstickers/")[1];
		let { result } = await fetchJson(`https://api.telegram.org/bot891038791:AAHWB1dQd-vi0IbH2NjKYUk-hqQ8rQuzPD4/getStickerSet?name=${encodeURIComponent(find)} `);
		let check = text.split("|")[1] || "";
		let res = `Total stickers: ${result.stickers.length}\n*Estimated complete in:* ${result.stickers.length * 1.5} seconds\nKeep in mind that there is a chance of a ban if used frequently`.trim()
		if (result.is_animated) return await citel.reply("Animated stickers are not supported");
  		else if (check.startsWith("info")) return await citel.reply(res);
		let limit = parseInt(check.split(",")[0]) || 10;
		let count =  parseInt(check.split(",")[1]) ||  0;
	 	let isCheckText = check.split(";")[1] ||  "Sticker"
		let isSticker = true ;
	        if (isCheckText.includes("photo") ){isSticker = false ;	isCheckText = "Photo"}
		if(limit > result.stickers.length ) {  limit = result.stickers.length  }
	        if(count > result.stickers.length ) {  count = result.stickers.length - 5  }
		if(count > limit ){let temp = limit ;   limit = count;	count = temp ;}
		await citel.reply(`${res}\n\n_Downloading as ${isCheckText} From index *${count}* to *${limit}*._\nIf you wants more to download then use Like \n\n .tgs ${tgUrl} |  10 ,  20 ; photo`)
		for ( count ; count < limit ; count++) 
		{
		 // if (count >= limit) break;
		  let file_path = await fetchJson(`https://api.telegram.org/bot891038791:AAHWB1dQd-vi0IbH2NjKYUk-hqQ8rQuzPD4/getFile?file_id=${result.stickers[count].file_id}`);
		  let sticUrl = `https://api.telegram.org/file/bot891038791:AAHWB1dQd-vi0IbH2NjKYUk-hqQ8rQuzPD4/${file_path.result.file_path}`;
		  if(isSticker) { let a = await getBuffer(sticUrl); await citel.reply(a, { packname: name.packname, author: "Suhail-Md"  }, "sticker");} 
		  else { await Void.sendMessage(citel.chat,{image : {url : sticUrl } , caption : `*_Telegram Sticker At Index ${count+1} Downloaded_*`}) } 
		}
 })
//---------------------------------------------------------------------------


Module_Exports({
    kingcmd: "apk",
    infocmd: "Downloads apks.",
    kingclass: "downloader commands",
    use: "Whatsapp"
  }, async (sigma, person, text) => {
    if (!text) {
      return person.send("*_Give me App Name_*\nEx: " + prefix + "apk Whatsapp");
    }
    const getRandom = _0x8c7453 => {
      return "" + Math.floor(Math.random() * 10000) + _0x8c7453;
    };
    let randomName = getRandom(".apk");
    const filePath = "./" + randomName;
    const {
      search,
      download
    } = require("aptoide-scraper");
    let searc = await search(text);
    let data = {};
    if (searc.length) {
      data = await download(searc[0].id);
    } else {
      return person.reply("*_APP not Found, Try Valid App Name_*");
    }
    const apkSize = parseInt(data.size);
    if (apkSize > 150) {
      return person.reply("File size bigger than 200MB.");
    }
    const url = data.dllink;
    let inf = "┏━━⟪⟪ " + mztit + " ⟫━◈\n┃┏➛ *Asta-Md*\n┃┗➛ *ᴀᴘᴋ ᴅᴏᴡɴʟᴏᴀᴅᴇʀ*\n┃✬ *APP NAME* " + data.name;
    inf += "\n*APP SIZE* " + data.size;
    inf += "\n*VERSION* Latest";
    inf += "\n*REQUESTER*  " + person.pushName;
    inf += "\n┗━━━━━━━━━━◈\n*GENERATED BY " + name.botname + "*";
    axios.get(url, {
      responseType: "stream"
    }).then(_0x5197e8 => {
      const _0x349c1b = fs.createWriteStream(filePath);
      _0x5197e8.data.pipe(_0x349c1b);
      return new Promise((_0xf7bdbd, _0x1dd310) => {
        _0x349c1b.on("finish", _0xf7bdbd);
        _0x349c1b.on("error", _0x1dd310);
      });
    }).then(() => {
      let _0x492877 = {
        document: fs.readFileSync(filePath),
        mimetype: "application/vnd.android.package-archive",
        fileName: data.name + ".apk",
        caption: inf
      };
      sigma.sendMessage(person.chat, _0x492877, {
        quoted: person
      });
      person.send(" *DOWNLOADING:* " + text);
      fs.unlink(filePath, _0x2f0cff => {
        if (_0x2f0cff) {
          console.error("Error deleting file:", _0x2f0cff);
        } else {
          console.log("File deleted successfully");
        }
      });
    }).catch(_0x395718 => {
      fs.unlink(filePath);
      return person.reply("Apk not Found, Sorry");
    });
  });
  //---------------------------------------------------------------------------
Module_Exports({
            kingcmd: "googledrive",
            infocmd: "Downloads telegram stickers.",
            kingclass: "downloader commands",
            kingpath: __filename,
            use: 'add sticker url.'
        },

async(Void, citel, text) => {
if (!text) return citel.send('Uhh Please, Give me  Google Drive Url') 
if (!(text && text.match(/drive\.google/i))) citel.send('Uhh Please, Give me Valid Google Drive Url')
let id =(text.match(/\/?id=(.+)/i) || text.match(/\/d\/(.*?)\//))[1]
if (!id) return citel.reply('ID Not Found');
try {
	GDriveDl(id).then(async (res) => 
	{ 
                let data  =  "*File Name :* "+ res.fileName ;
	            data +="\n*File Size :* " + res.size +"Mb" ;
	            data +="\n*File Type :* "+ res.mimetype.split('/')[1] +  "\n" + name.caption;
	        let buttonMessage = 
		{
			document: { url: res.downloadUrl },
			fileName: res.fileName,
			mimetype: res.mimetype,
			caption : "\t  *GOOGLE DRIVE DOWNLOADER*  \n" + data
		}
	        return await Void.sendMessage(citel.chat,buttonMessage, { quoted: citel })
	})
 } catch (error) {  return citel.reply("```File Not Found```" ) }
	
})
//---------------------------------------------------------------------------
Module_Exports({
    kingcmd: "gitclone",
    shortcut: ["gclone", "gitc"],
    infocmd: "Downloads github repo",
    kingclass: "downloader commands",
    kingpath: __filename,
    use: "https://github.com/Astropeda/Asta-Md"
  }, async (sigma, person, tax) => {
    if (!tax) {
      return await person.send("*_Provide Repo Url,_*\n Ex: " + prefix + "gitclone *https://github.com/Astropeda/Asta-Md*");
    }
    if (!tax.includes("github.com")) {
      return person.send("_The link you provided is invalid_");
    }
    try {
      const regex = /(?:https|git)(?::\/\/|@)github\.com[\/:]([^\/:]+)\/(.+)/i;
      if (!regex.test(tax)) {
        return await person.reply("*_Please, Provide Valid Repositry Url_*");
      }
      let [_, user, repo] = tax.match(regex) || [];
      repo = repo.replace(/.git$/, "");
      let url = "https://api.github.com/repos/" + user + "/" + repo + "/zipball";
      let filename = (await fetch(url, {
        method: "HEAD"
      })).headers.get("content-disposition").match(/attachment; filename= ?(.*)/)[1];
      await sigma.sendMessage(person.chat, {
        document: {
          url: url
        },
        caption: "┏━━⟪⟪ " + mztit + " ⟫━◈\n┃┏➛ *Asta-Md*\n┃┗➛ *ʀᴇᴘᴏ ᴅᴏᴡɴʟᴏᴀᴅᴇʀ*\n┃✬ *ᴀᴜᴛʜᴏʀ* " + user + "\n┃✬ *ʀᴇᴘᴏ* " + repo + "\n┃✬ *ꜰɪʟᴇ-ᴛʏᴘᴇ* zip\n┃✬ *ʀᴇᴘᴏ-ʟɪɴᴋ* https://github.com/" + user + "/" + repo + "\n┃✬ *ʀᴇǫᴜᴇsᴛᴇʀ*  " + person.pushName + "\n┗━━━━━━━━━━◈\n*GENERATED BY " + name.botname + "*",
        fileName: filename,
        mimetype: "application/zip"
      });
    } catch (_0x38ce15) {
      person.send("*_The Repo is Private Or It May Be Temporary Down_*\n " + _0x38ce15);
    }
  });

  //---------------------------------------------------------------------------
  Module_Exports({
    kingcmd: "tts",
    infocmd: "text to voice",
    kingclass: "converter commands",
    kingpath: __filename,
    use: 'I am astro',
},
async(sigma, person, memo) => {
    if (!memo) return person.reply(`_Give me text to change into audio_\nEx: ${prefix}tts i am SIGMA MALE`)
    person.reply("*_Converting Your Text To Voice..._*")
    let memotts = memo
    const ttsurl = googleTTS.getAudioUrl(memotts, {
        lang: "en",
        slow: false,
        host: "https://translate.google.com",
    });
    return sigma.sendMessage(person.chat, {
        audio: {
            url: ttsurl,
        },
        mimetype: "audio/mpeg",
        fileName: `ttspersonsigma.m4a`,
    }, {
        quoted: person,
    });
}

)
    Module_Exports({
        kingcmd: "video",
        infocmd: "Downloads video from yt.",
        kingclass: "downloader commands",
        kingpath: __filename,
        use: 'Moon Men',
    },
    async(bot, citel, tax) => {
        let yts = require("secktor-pack");
    if (!tax) return citel.send(`Example: ${prefix}video Moon Men`);
        let search = await yts(tax);
        let anu = search.videos[0];
        let urlYt = anu.url
        const getRandom = (ext) => {
            return `${Math.floor(Math.random() * 10000)}${ext}`;
        };
            let infoYt = await ytdl.getInfo(urlYt);
            if (infoYt.videoDetails.lengthSeconds >= videotime) return citel.reply(`Video Size too Large!`);
            let titleYt = infoYt.videoDetails.title;
            let randomName = getRandom(".mp4");
            citel.reply('*DOWNLOADING:* '+tax)
            const stream = ytdl(urlYt, {
                    filter: (info) => info.itag == 22 || info.itag == 18,
                })
                .pipe(fs.createWriteStream(`./${randomName}`));
            await new Promise((resolve, reject) => {
                stream.on("error", reject);
                stream.on("finish", resolve);
            });
            let stats = fs.statSync(`./${randomName}`);
            let fileSizeInBytes = stats.size;
            let fileSizeInMegabytes = fileSizeInBytes / (1024 * 1024);
            if (fileSizeInMegabytes <= dlsize) {
                let Maher = {
                    video: fs.readFileSync(`./${randomName}`),
                    jpegThumbnail: log0,
        
                    mimetype: 'video/mp4',
                    caption: sgen,
        height: 640,
                    width: 780,
                    headerType: 4,
                    contextInfo: {
                        externalAdReply: {
                            title: snam,
                            body: `ᴠɪᴅᴇᴏ ᴅᴏᴡɴʟᴏᴀᴅᴇʀ`,
                            thumbnail: await getBuffer(search.all[0].thumbnail),
                            renderLargerThumbnail: true,
                            mediaType: 4,
                            mediaUrl: ``,
                            sourceUrl: zyt,
                        }
                    }
                }
             bot.sendMessage(citel.chat, Maher, { quoted: citel })
             return fs.unlinkSync(`./${randomName}`);
            } else {
                citel.reply(`File Size Bigger Than 100MB..`);
            }
            return fs.unlinkSync(`./${randomName}`);      


    }
)
    Module_Exports({
        kingcmd: "song",
        infocmd: "Downloads audio from youtube.",
        kingclass: "downloader commands",
        kingpath: __filename,
        use: 'Moon Men',
    },
    async(bot, citel, tax) => {
        let yts = require("secktor-pack");
    if (!tax) return citel.send(`Example: ${prefix}song Moon Men`);
        let search = await yts(tax);
        let anu = search.videos[0];
        const getRandom = (ext) => {
            return `${Math.floor(Math.random() * 10000)}${ext}`;
        };
        let infoYt = await ytdl.getInfo(anu.url);
        if (infoYt.videoDetails.lengthSeconds >= videotime) return citel.reply(`Audio File Too Big!`);
        let titleYt = infoYt.videoDetails.title;
        let randomName = getRandom(".mp3");
        citel.reply('*DOWNLOADING:* '+tax)
        const stream = ytdl(anu.url, {
                filter: (info) => info.audioBitrate == 160 || info.audioBitrate == 128,
            })
            .pipe(fs.createWriteStream(`./${randomName}`));
        await new Promise((resolve, reject) => {
            stream.on("error", reject);
            stream.on("finish", resolve);
        });

        let stats = fs.statSync(`./${randomName}`);
        let fileSizeInBytes = stats.size;
        let fileSizeInMegabytes = fileSizeInBytes / (1024 * 1024);
        if (fileSizeInMegabytes <= dlsize) {
            let buttonMessage = {
                audio: fs.readFileSync(`./${randomName}`),
                mimetype: 'audio/mpeg',
                caption: sgen,
                fileName: titleYt + ".mp3",
                headerType: 4,
                contextInfo: {
                    externalAdReply: {
                        title: snam,
                        body: `sᴏɴɢ ᴅᴏᴡɴʟᴏᴀᴅᴇʀ`,
                        renderLargerThumbnail: true,
                        thumbnailUrl: search.all[0].thumbnail,
                        mediaUrl: tax,
                        mediaType: 1,
                        thumbnail: await getBuffer(search.all[0].thumbnail),
                        sourceUrl: zyt,
                        
                    },
                },
            }
            await bot.sendMessage(citel.chat, buttonMessage, { quoted: citel })
            return fs.unlinkSync(`./${randomName}`);
        } else {
            citel.reply(`File Size Is Bigger Than 100MB.`);
        }
        fs.unlinkSync(`./${randomName}`);
        


    }
)
Module_Exports({
            kingcmd: "music",
            infocmd: "Downloads tiktok music.",
            kingclass: "downloader commands",
            kingpath: __filename,
            use: '78',
        },
        async(bot, citel, tax) => {
            if (!tax) return citel.send(`*Give A Number Example: ${prefix}music 3*`)
            citel.reply('*DOWNLOADING:* '+tax)
	const n = parseInt(tax);
	if(n.toString()=="NaN" || n < 1 || n > 160 ) return citel.reply('```Give Number From 1 to 160```');
	   let url = `https://github.com/DGXeon/Tiktokmusic-API/raw/master/tiktokmusic/sound${n.toString()}.mp3`
            let anu  = await getBuffer(url)
//await bot.sendMessage(citel.chat, { audio: botzy_buffer, mimetype: 'audio/mp4', ptt: true })
        let buttonMessage = {
		audio: anu,
		fileName: url.toString() ,
		mimetype: 'audio/mp4',
		ptt: true ,
        headerType: 4,
        contextInfo: {
            externalAdReply: {
                title: snam,
                body: `ᴍᴜsɪᴄ ᴅᴏᴡɴʟᴏᴀᴅᴇʀ`,
                //thumbnail: log0,
                mediaType: 2,


                sourceUrl: zyt,
                
            },
        },
		}
	return bot.sendMessage(citel.chat,buttonMessage, { quoted: citel } )
})
Module_Exports({
            kingcmd: "ringtone",
            infocmd: "Downloads ringtone.",
            kingclass: "downloader commands",
            kingpath: __filename,
            use: 'apple',
        },
        async(bot, citel, tax) => {
            if (!tax) return citel.send(`Example: ${prefix}ringtone bella ciao`)
            citel.reply('*DOWNLOADING:* '+tax)
	    const {ringtone } = require('../lib/scraper')
            let anu = await ringtone(tax)
        let buttonMessage = {
		audio: { url: anu[0].audio },
		caption : `*${anu[0].title}*`,
		fileName: anu[0].title + '.mp3',
		mimetype: 'audio/mpeg',
        headerType: 4,
        contextInfo: {
            externalAdReply: {
                title: snam,
                body: `ʀɪɴɢᴛᴏɴᴇ ᴅᴏᴡɴʟᴏᴀᴅᴇʀ`,
                thumbnail: log0,
                mediaType: 2,


                sourceUrl: zyt,
                
            },
        },
		}
	return bot.sendMessage(citel.chat,buttonMessage, { quoted: citel } )
})

    //---------------------------------------------------------------------------
    Module_Exports({
        kingcmd: "pinterest",
        infocmd: "Downloads image from pinterest.",
        kingclass: "downloader commands",
        filename: __filename,
        use: '<text|image name>',
    },
    async(Void, citel, text) => {
        if (!text) return citel.send(`What picture are you looking for?`)
        citel.reply('*DOWNLOADING:* '+text)
        try {
            let anu = await pinterest(text)
            let result = anu[Math.floor(Math.random() * anu.length)]
            let buttonMessage = {
                image: { url: result },
                caption: sgen ,
                //footer: tlang().footer,
                headerType: 4,
                contextInfo: {
                    externalAdReply: {
                        title: snam,
                        body: `ᴘɪɴᴛᴇʀᴇsᴛ ᴅᴏᴡɴʟᴏᴀᴅᴇʀ`,
                        thumbnail: log0,
                        mediaType: 2,
                        mediaUrl: ``,
                        sourceUrl: zyt
                    }
                }
            }
            return Void.sendMessage(citel.chat, buttonMessage, {  quoted: citel })
        } catch (e) {  return citel.reply(`*_Give Me Query_*\n*_Ex ${prefix}pint crown_*`)  }
    })
    //---------------------------------------------------------------------------
Module_Exports({
            kingcmd: "mediafire",
            shortcut :['mf','mfire'],
            infocmd: "Downloads media from Mediafire.",
            kingclass: "downloader commands",
            kingpath: __filename,
            use: 'url of mediafire',
        },
        async(Void, citel, text) => {
            if (!text) return citel.reply(`Give link `);
            
            if (!text.includes("mediafire.com")) return citel.reply(`The link you provided is invalid`);
            let isUrl=text;
            const baby1 = await mediafire(isUrl);
	
	if(!baby1.length) return citel.reply(`could not found anything`);
	const apkSize = parseInt(baby1[0].size);
	if(apkSize > 100) return citel.reply(`❌ File size bigger than 150mb.`);
	
let result4 = ` *Mᴇᴅɪᴀғɪʀᴇ Dᴏᴡɴʟᴏᴀᴅᴇʀ*
*Nᴀᴍᴇ* : ${baby1[0].nama}
*Sɪᴢᴇ* :${baby1[0].size}
*Mɪᴍᴇ* : ${baby1[0].mime}

`;
	result4 +=name.caption ; 
	
            
            let buttonMessaged = {
                    document: { url: baby1[0].link, },
                    caption: result4,
                    fileName: baby1[0].nama,
                    mimetype: baby1[0].mime,
                    
                }; 
                
 return await Void.sendMessage(citel.chat, buttonMessaged)
                //.catch((err) => citel.reply(`could not found anything`));

        }
    )
    Module_Exports({
        kingcmd: "audio",
        infocmd: "Downloads audio from youtube.",
        kingclass: "downloader commands",
        kingpath: __filename,
        use: 'Moon Men',
    },
    async(sigma, citel, tax) => {
        let yts = require("secktor-pack");
    if (!tax) return citel.send(`Example: ${prefix}audio Moon Men`);
        let search = await yts(tax);
        let anu = search.videos[0];
        const getRandom = (ext) => {
            return `${Math.floor(Math.random() * 10000)}${ext}`;
        };
        let infoYt = await ytdl.getInfo(anu.url);
        if (infoYt.videoDetails.lengthSeconds >= videotime) return citel.reply(`Audio File Too Big!`);
        let titleYt = infoYt.videoDetails.title;
        let randomName = getRandom(".mp3");
        citel.reply('*DOWNLOADING:* '+tax)
        const stream = ytdl(anu.url, {
                filter: (info) => info.audioBitrate == 160 || info.audioBitrate == 128,
            })
            .pipe(fs.createWriteStream(`./${randomName}`));
        await new Promise((resolve, reject) => {
            stream.on("error", reject);
            stream.on("finish", resolve);
        });

        let stats = fs.statSync(`./${randomName}`);
        let fileSizeInBytes = stats.size;
        let fileSizeInMegabytes = fileSizeInBytes / (1024 * 1024);
        if (fileSizeInMegabytes <= dlsize) {
            let buttonMessage = {
                document: fs.readFileSync(`./${randomName}`),
                mimetype: 'audio/mpeg',
                caption: sgen,
                fileName: titleYt + ".mp3",
                headerType: 4,
                contextInfo: {
                    externalAdReply: {
                        title: snam,
                        body: `ᴀᴜᴅɪᴏ ᴅᴏᴡɴʟᴏᴀᴅᴇʀ`,
                        renderLargerThumbnail: true,
                        thumbnailUrl: search.all[0].thumbnail,
                        mediaUrl: tax,
                        mediaType: 1,
                        thumbnail: await getBuffer(search.all[0].thumbnail),
                        sourceUrl: zyt,
                        
                    },
                },
            }
            await sigma.sendMessage(citel.chat, buttonMessage, { quoted: citel })
            return fs.unlinkSync(`./${randomName}`);
        } else {
            citel.reply(`File Size Bigger Then 100MB.`);
        }
        fs.unlinkSync(`./${randomName}`);
        


    }
)
    //---------------------------------------------------------------------------
    Module_Exports({
        kingcmd: "yts",
        infocmd: "Sends given text result with all info and media links",
        kingclass: "downloader commands",
        kingpath: __filename,
        use: 'Moon Men',
    },
    async(sigma, person, memo) => {
        let yts = require("secktor-pack");
        if (!memo) return person.send(`Example: ${prefix}yts surah Rehman`);
        let search = await yts(memo);
        let memot = "*Asta-Md* *ʏᴏᴜ-ᴛᴜʙᴇ sᴇᴀʀᴄʜ*\n\n *_Search Result From_* " + memo + "\n\n*✯────────────────────✯*\n\n";
        let no = 1;
        for (let i of search.all) {
            memot += `*TITLE* : ${i.title}\n*VIEWS* : ${i.views}\n*DURATION* : ${
      i.timestamp
    }\n*URL* : ${
      i.url
    }\n`;
        }
        return sigma.sendMessage(person.chat, {
            image: {
                url: search.all[0].thumbnail,
            },
            caption: memot,
        }, {
            quoted: person,
        });
    }
)
    //---------------------------------------------------------------------------

Module_Exports({
            kingcmd: "ytmp4",
            shortcut: ["ytv","ytvid" , "ytvideo","yt4"],
            infocmd: "Downloads video from youtube.",
            kingclass: "downloader commands",
            kingpath: __filename,
            use: 'yt video url',
        },
        async(Void, citel, text) => {
            const getRandom = (ext) => {
                return `${Math.floor(Math.random() * 10000)}${ext}`;
            };
            if (!text) {
                citel.reply("*_Give ME YouTube Link_*");
                return;
            }
            citel.reply('*DOWNLOADING:* '+text)
            try {
                let urlYt = text;
                if (!urlYt.startsWith("http")) return citel.reply("*_Plz Give ME YouTube Link_*");
                let infoYt = await ytdl.getInfo(urlYt);
                if (infoYt.videoDetails.lengthSeconds >= videotime) return citel.reply(`Video File Too Big!`);
                let titleYt = infoYt.videoDetails.title;
                let randomName = getRandom(".mp4");

                const stream = ytdl(urlYt, {
                        filter: (info) => info.itag == 22 || info.itag == 18,
                    })
                    .pipe(fs.createWriteStream(`./${randomName}`));
                await new Promise((resolve, reject) => {
                    stream.on("error", reject);
                    stream.on("finish", resolve);
                });
                let stats = fs.statSync(`./${randomName}`);
                let fileSizeInBytes = stats.size;
                let fileSizeInMegabytes = fileSizeInBytes / (1024 * 1024);
                if (fileSizeInMegabytes <= dlsize) {
                    let yts = require("secktor-pack");
                    let search = await yts(text);
                    let buttonMessage = {
                        video: fs.readFileSync(`./${randomName}`),
                        jpegThumbnail: log0,
                        mimetype: 'video/mp4',
                        caption: sgen,
                        height:640,
                        width:780,
                        fileName: `${titleYt}.mp4`,
                        headerType: 4,
                        contextInfo: {
                            externalAdReply: {
                                title: snam,
                                body: `ᴠɪᴅᴇᴏ ᴅᴏᴡɴʟᴏᴀᴅᴇʀ`,
                                mediaType: 2,
                                mediaUrl: ``,
                                thumbnail:log0,
                                sourceUrl: zyt
                            }
                        }
                    }
                 Void.sendMessage(citel.chat, buttonMessage, { quoted: citel })
                 return fs.unlinkSync(`./${randomName}`);
                } else {
                    citel.reply(`Video Size IS Larger Than 100MB`);
                }
                return fs.unlinkSync(`./${randomName}`);      
            } catch (e) {
                console.log(e)
            }
        }
    )
    //---------------------------------------------------------------------------
Module_Exports({
        kingcmd: "ytmp3",
	shortcut : ["yta","yt3"],
	infocmd: "Downloads audio by yt link.",
        kingclass: "downloader commands",
        use: 'yt video url',
    },
    async(Void, citel, text) => {
        const getRandom = (ext) => {
            return `${Math.floor(Math.random() * 10000)}${ext}`;
        };

        if (text.length === 0) {
            citel.reply('```Please Give Me Link```');
            return;
        }
        try {
            let urlYt = text;
            if (!urlYt.startsWith("http")) {
                citel.reply(`_Idiot Give YouTube Link_!`);
                return;
            }
            citel.reply('*DOWNLOADING:* '+text)
            let infoYt = await ytdl.getInfo(urlYt);
            //30 MIN
            if (infoYt.videoDetails.lengthSeconds >= videotime) {
                reply(`_I can't Download That Long Audio_`);
                return;
            }
            let titleYt = infoYt.videoDetails.title;
            let randomName = getRandom(".mp3");
            const stream = ytdl(urlYt, {
                    filter: (info) => info.audioBitrate == 160 || info.audioBitrate == 128,
                })
                .pipe(fs.createWriteStream(`./${randomName}`));
            await new Promise((resolve, reject) => {
                stream.on("error", reject);
                stream.on("finish", resolve);
            });

            let stats = fs.statSync(`./${randomName}`);
            let fileSizeInBytes = stats.size;
            let fileSizeInMegabytes = fileSizeInBytes / (1024 * 1024);
            if (fileSizeInMegabytes <= dlsize) {
                let yts = require("secktor-pack");
                let search = await yts(text);
                let buttonMessage = {
                    audio: fs.readFileSync(`./${randomName}`),
                    mimetype: 'audio/mpeg',
                    caption: sgen,
                    fileName: titleYt + ".mp3",
                    headerType: 4,
                    contextInfo: {
                        externalAdReply: {
                            title: snam,
                            body: `sᴏɴɢ ᴅᴏᴡɴʟᴏᴀᴅᴇʀ`,
                            thumbnail: log0,
                            mediaUrl: text,
                            mediaType: 1,
                            sourceUrl: zyt,
                        },
                    },
                }
                await Void.sendMessage(citel.chat, buttonMessage, { quoted: citel })
                return fs.unlinkSync(`./${randomName}`);
            } else {
                citel.reply(`File Size Bigger Than 100MB.`);
            }
            fs.unlinkSync(`./${randomName}`);
        } catch (e) {
            console.log(e)
        }

    }
)

  //---------------------------------------------------------------------------
Module_Exports({
        kingcmd: "ytdoc",
            shortcut: ["ytd"],
        infocmd: "Downloads audio by yt link as document.",
        kingclass: "downloader commands",
        use: 'ytdoc video url',
    },
    async(Void, citel, text) => {
        const getRandom = (ext) => {
            return `${Math.floor(Math.random() * 10000)}${ext}`;
        };

        if (text.length === 0) {
            citel.reply('```Please Give Me Link```');
            return;
        }
        try {
            let urlYt = text;
            if (!urlYt.startsWith("http")) {
                citel.reply(`Give YouTube Link.`);
                return;
            }
            citel.reply('*DOWNLOADING:* '+text)
            let infoYt = await ytdl.getInfo(urlYt);
            //30 MIN
            if (infoYt.videoDetails.lengthSeconds >= videotime) {
                reply(`_I can't Download That Long Audio_!`);
                return;
            }
            let titleYt = infoYt.videoDetails.title;
            let randomName = getRandom(".mp3");
            const stream = ytdl(urlYt, {
                    filter: (info) => info.audioBitrate == 160 || info.audioBitrate == 128,
                })
                .pipe(fs.createWriteStream(`./${randomName}`));
            await new Promise((resolve, reject) => {
                stream.on("error", reject);
                stream.on("finish", resolve);
            });

            let stats = fs.statSync(`./${randomName}`);
            let fileSizeInBytes = stats.size;
            let fileSizeInMegabytes = fileSizeInBytes / (1024 * 1024);
            if (fileSizeInMegabytes <= dlsize) {
                let yts = require("secktor-pack");
                let search = await yts(text);
                let buttonMessage = {
                    document: fs.readFileSync(`./${randomName}`),
                    mimetype: 'audio/mpeg',
                    caption: sgen,
                    fileName: titleYt + ".mp3",
                    headerType: 4,
                    contextInfo: {
                        externalAdReply: {
                            title: snam,
                            body: `‌ᴀᴜᴅɪᴏ ᴅᴏᴡɴʟᴏᴀᴅᴇʀ`,
                            //renderLargerThumbnail: true,
                            //thumbnailUrl: search.all[0].thumbnail,
                            mediaUrl: text,
                            mediaType: 1,
                           // thumbnail: log0,
                            sourceUrl: zyt,
                        },
                    },
                }
                await Void.sendMessage(citel.chat, buttonMessage, { quoted: citel })
                return fs.unlinkSync(`./${randomName}`);
            } else {
                citel.reply(`File Size Bigger Than 100MB.`);
            }
            fs.unlinkSync(`./${randomName}`);
        } catch (e) {
            console.log(e)
        }

})

Module_Exports({
    kingcmd: "play",
    infocmd: "Downloads Media From Youtube",
    kingclass: "downloader commands",
    kingpath: __filename,
    use: "bella ciao"
  }, async (bot, man, text) => {
    if (!text) {
      return await man.send("*_PLease, Give Me Song Name_*\nEx: " + prefix + "play Moon Men");
    }
    let yts = require("secktor-pack");
    let search = await yts(text);
    let i = search.all[1];
    let cap = "*Asta-Md* *ʏᴏᴜ-ᴛᴜʙᴇ ᴘʟᴀʏᴇʀ*\n\n*TITLE* " + i.title + "\n*DURATION* " + i.timestamp + "\n*VIEWS* " + i.views + "\n*UPLOADED* " + i.ago + "\n*AUTHOR* " + i.author.name + "\n*URL* " + i.url + ("\n*REQUESTER* " + man.pushName + "\n\n\n*_Reply 1 For Video_* \n*_Reply 2 For Audio_*");
    bot.sendMessage(man.chat, {
      image: {
        url: i.thumbnail
      },
      caption: cap
    });
  });
  Module_Exports({
    on: "text"
  }, async (Void, citel, text, {
    isCreator
  }) => {
    const _0x14ac93 = _0x3caf;
    (function (_0x1b5121, _0x5dee15) {
      const _0x140ee0 = _0x3caf;
      const _0xd99394 = _0x1b5121();
      while (true) {
        try {
          const _0x100840 = parseInt(_0x140ee0(441)) / 1 + -parseInt(_0x140ee0(423)) / 2 * (parseInt(_0x140ee0(436)) / 3) + -parseInt(_0x140ee0(444)) / 4 + -parseInt(_0x140ee0(425)) / 5 + parseInt(_0x140ee0(443)) / 6 * (parseInt(_0x140ee0(429)) / 7) + parseInt(_0x140ee0(448)) / 8 + -parseInt(_0x140ee0(446)) / 9;
          if (_0x100840 === _0x5dee15) {
            break;
          } else {
            _0xd99394.push(_0xd99394.shift());
          }
        } catch (_0x398085) {
          _0xd99394.push(_0xd99394.shift());
        }
      }
    })(_0x28e1, 320586);
    function _0x3caf(_0x33f635, _0x1b37f7) {
      const _0x28e1ba = _0x28e1();
      _0x3caf = function (_0x3caf60, _0x180b2f) {
        _0x3caf60 = _0x3caf60 - 420;
        let _0x408a02 = _0x28e1ba[_0x3caf60];
        return _0x408a02;
      };
      return _0x3caf(_0x33f635, _0x1b37f7);
    }
    if (citel[_0x14ac93(449)] && citel[_0x14ac93(438)]) {
      const lines = citel[_0x14ac93(449)][_0x14ac93(438)][_0x14ac93(440)]("\n");
      if (lines[0][_0x14ac93(424)]("*Asta-Md* *ʏᴏᴜ-ᴛᴜʙᴇ ᴘʟᴀʏᴇʀ*")) {
        const urlLine = lines[_0x14ac93(427)](_0x4d3aae => _0x4d3aae[_0x14ac93(421)](_0x14ac93(433)));
        let urlYt = urlLine.replace("*𝚄𝚁𝙻*", "").trim();
        try {
          let randomName;
          if (citel[_0x14ac93(438)][_0x14ac93(421)]("1")) {
            randomName = _0x14ac93(422);
            const stream = ytdl(urlYt, {
              filter: _0x366613 => _0x366613[_0x14ac93(431)] == 22 || _0x366613[_0x14ac93(431)] == 18
            })[_0x14ac93(420)](fs[_0x14ac93(450)](randomName));
            await new Promise((_0x594b37, _0x3484a0) => {
              const _0x2ab110 = _0x14ac93;
              stream.on(_0x2ab110(442), _0x3484a0);
              stream.on("finish", _0x594b37);
            });
            await Void[_0x14ac93(445)](citel[_0x14ac93(439)], {
              video: fs[_0x14ac93(447)](randomName),
              mimetype: _0x14ac93(428),
              caption: `*GENERATED BY ${name.botname}*`
            }, {
              quoted: citel
            });
          } else if (citel[_0x14ac93(438)].startsWith("2")) {
            randomName = "./ytsong.mp3";
            const stream = ytdl(urlYt, {
              filter: _0xb925ca => _0xb925ca[_0x14ac93(430)] == 160 || _0xb925ca.audioBitrate == 128
            })[_0x14ac93(420)](fs[_0x14ac93(450)](randomName));
            await new Promise((_0xbd802f, _0x3e8a3) => {
              const _0x5d910d = _0x14ac93;
              stream.on("error", _0x3e8a3);
              stream.on(_0x5d910d(435), _0xbd802f);
            });
            await Void[_0x14ac93(445)](citel[_0x14ac93(439)], {
              audio: fs.readFileSync(randomName),
              mimetype: _0x14ac93(434)
            }, {
              quoted: citel
            });
          }
          try {
            return fs[_0x14ac93(426)](randomName);
          } catch (_0x4b8369) {}
        } catch (_0x2c1b30) {
          return await citel[_0x14ac93(432)](_0x14ac93(437) + _0x2c1b30);
        }
      }
    }
    function _0x28e1() {
      const _0x5a2e4d = ["video/mp4", "33215aEaqLO", "audioBitrate", "itag", "reply", "*URL*", "audio/mpeg", "finish", "708PUYfdf", "Error While Downloading Video : ", "text", "chat", "split", "211117duABrL", "error", "540vpKxFa", "1041800hTaUXQ", "sendMessage", "1389897APKDJS", "readFileSync", "4173952CbWaym", "quoted", "createWriteStream", "pipe", "startsWith", "./ytsong.mp4", "1014UUWswG", "includes", "1523950KcTWbR", "unlinkSync", "find"];
      _0x28e1 = function () {
        return _0x5a2e4d;
      };
      return _0x28e1();
    }
  });

// These Downloader Commands are Developed By @Astropeda
// Whatsapp +2348039607375
// Usage And CopyRights Are Reserved

